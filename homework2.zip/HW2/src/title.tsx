import './App.css';

const Title = ({about}: {about: string}) => {
    return(
        <p>{about}</p>
    );
}

export default Title;
