import './App.css';
import './list.css'
function List() {
    return (
        <ul>
        <li>Cooking</li>
            <li>Sleeping</li>
            <li>Ultimate Frisbee</li>
            <li>Gaming</li>
            <li>Gym</li>
            <li>Basketball</li>
            <li>Movies</li>
            <li>Karaoke</li>
            <li>Hiking</li>
            <li>Youtube</li>
            <li>Spike-ball</li>
            <li>Road-trips</li>
            <li>Shopping</li>
            <li>Bowling</li>
            <li>Card Games</li>
            <li>Getting Dinner</li>
            <li>BTD6</li>
        </ul>
    );
}

export default List;
